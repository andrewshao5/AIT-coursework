// require your module, connectmoji
// require any other modules that you need, like clear and readline-sync
const clear = require('clear');
const gameBoard = require('./connectmoji.js');
const readlineSync = require('readline-sync');
if (process.argv.length > 2) {
    const parts = process.argv[2].split(',');
    const user = parts[0];
    const moveString = parts[1];
    const moveStringArray = [...moveString];
    const computer = moveStringArray[1];
    const rows = parseInt(parts[2]);
    const cols = parseInt(parts[3]);
    const consecutivePiecesNeeded = parseInt(parts[4]);
    let board = gameBoard.generateBoard(rows, cols);
    const gameResult = gameBoard.autoplay(board, moveString, consecutivePiecesNeeded);

    clear();
    readlineSync.question('\n\nAutoplay is finished...\n\nPlease press ENTER to continue');
        console.log('\nThe game will continue with manual play.');

        let currentUser = gameResult.lastPieceMoved;

        if (currentUser === user) {
            currentUser = computer;
        } else {
            currentUser = user;
        }

        console.log('\nIt is the  ' + currentUser + 's turn.');

        const whoseTurn = currentUser;
        console.log("\n\n");
        readlineSync.question('Press <ENTER> to continue:');
        console.log(gameBoard.boardToString(gameResult.board));
        board = gameResult.board;

        gameBoard.playGame(board, whoseTurn, user, computer, consecutivePiecesNeeded);
    }
else {
        let rows;
        let cols;
        let consecutivePiecesNeeded;

        clear();
        const basicGameInfo = readlineSync.question(`\n\nEnter the number of rows, columns, and consecutive "pieces" for win all separated by commas...for example: 6,7,4\n> `);
        const info = basicGameInfo.split(',');
        if (info.length < 3) {
            console.log('\n\nUsing row, col and consecutive: ', 6, 7, 4);
            rows = 6;
            cols = 7;
            consecutivePiecesNeeded = 4;
        } else {
            rows = parseInt(info[0]);
            cols = parseInt(info[1]);
            consecutivePiecesNeeded = parseInt(info[2]);
            console.log('\n\nUsing row, col and consecutive: ', rows, cols, consecutivePiecesNeeded);
        }

        const getEmojis = readlineSync.question(`\n\nEnter two characters or emojis that represent the user and computer (separated by a comma... for example: P,C)\n> `);
        let user, computer;
        if (getEmojis.length === 0) { //user doesn't specify, use default
            user = '😎';
            computer = '💻';
            console.log("\n\nUsing default player and computer characters " + user + "," + computer);
        } else if (getEmojis.length === 1) { //only 1 character is specified
            const emojiArray = getEmojis.split(',');
            user = emojiArray[0];
            computer = '😜';
            console.log("\n\nUsing this character for player" + user + "," + computer);
        } else {
            const emojiArray = getEmojis.split(',');
            user = emojiArray[0];
            computer = emojiArray[1];
            console.log('\n\nUsing user and computer characters:', user, computer);
        }

        let whoseTurn;
        const firstMove = readlineSync.question(`\nWho goes first, (P)layer or (C)omputer?\n> `);
        if (firstMove.length === 0) {
            console.log("\nPlayer goes first");
        } else if ((firstMove !== 'P' && firstMove !== 'C')) {
            console.log("\nPlayer goes first");
            whoseTurn = user;
        } else if (firstMove === 'P') {
            console.log("\nPlayer goes first");
            whoseTurn = user;
        } else {
            console.log("\nComputer goes first");
            whoseTurn = computer;
        }

        readlineSync.question('Press <ENTER> to start game');
        const board = gameBoard.generateBoard(rows, cols);
        console.log(gameBoard.boardToString(board));

        gameBoard.playGame(board, whoseTurn, user, computer, consecutivePiecesNeeded);
    }








