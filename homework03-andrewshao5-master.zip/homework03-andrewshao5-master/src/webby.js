// webby.js
const net = require("net"); 
const path = require('path');
const fs = require('fs');

const HTTP_STATUS_CODES = {
    200: 'OK',
    404: 'Not Found',
    500: 'Internal Server Error'
};

const MIME_TYPES = {
    jpg: 'image/jpeg',
    jpeg: 'image/jpeg',
    png: 'image/png',
    html: 'text/html',
    css: 'text/css',
    txt: 'text/plain'
};
function getExtension(fileName) {

    if (fileName.includes('.')) {
        const tempString = fileName.split('.');
        return tempString[tempString.length - 1].toLowerCase();
    } else {
        return '';
    }

}

function getMIMEType(fileName) {

    if (fileName.includes('.')) {
        const tempString = fileName.split('.');
        if (tempString[tempString.length - 1] == 'jpg') {

            return MIME_TYPES.jpg;

        } else if (tempString[tempString.length - 1] == 'jpeg') {

            return MIME_TYPES.jpeg;

        } else if (tempString[tempString.length - 1] == 'png') {

            return MIME_TYPES.png;

        } else if (tempString[tempString.length - 1] == 'html') {

            return MIME_TYPES.html;

        } else if (tempString[tempString.length - 1] == 'css') {

            return MIME_TYPES.css;

        } else if (tempString[tempString.length - 1] == 'txt') {

            return MIME_TYPES.txt;
        }
    } else {
        return '';
    }
}

class Request {
    constructor(s) {
        const [method, path] = s.split(' ');
        this.method = method;
        this.path = path;
    }
}

class Response {
    constructor(socket, statusCode, version) {
        this.sock = socket;
        this.headers = {};
        this.body = null;
        if (version === undefined) {
            this.version = "HTTP/1.1";
        }
        else {
            this.version = version;
        }
        if (statusCode === undefined) {
            this.statusCode = 200;
        }
        else {
            this.statusCode = statusCode;
        }
    }

    set(name, value) {
        this.headers[name] = value;
    }

    end() {
        this.sock.end();
    }

    statusLineToString() {
        let resString = "";
        resString += this.version;
        resString += " ";
        resString += this.statusCode;
        resString += " ";
        resString += HTTP_STATUS_CODES[this.statusCode];
        resString += "\r\n";
        return resString;
    }

    headersToString() {
        let headerString = "";
        for (const key in this.headers) {
            headerString += key;
            headerString += ": ";
            headerString += this.headers[key];
            headerString += "\r\n";
        }
        return headerString;
    }

    status(statusCode) {
        this.statusCode = statusCode;
        return this;
    }

    send(body) {
        this.body = body;
        let s = '';
        let statusLine;
        let contentTypes;
        if (Object.prototype.hasOwnProperty.call(this.headers, 'Content-Type')) {
           statusLine = this.statusLineToString();
           contentTypes = this.headersToString();
        }
        else {
           this.headers['Content-Type'] = 'text/html';
           statusLine = this.statusLineToString();
           contentTypes = this.headersToString();
        }
        s = `${statusLine}`;
        s += `${contentTypes}\r\n`;
        this.sock.write(s);
        this.sock.write(body);
        this.sock.end();
    }
}

class App {
    constructor() {
        this.server = net.createServer((sock) => {
            this.handleConnection(sock);
        }); 
        this.routes = {};
        this.middleware = null;
    }

    normalizePath(path) { 
        let normalPath = "";
        let idx = 0;
        while (idx <= path.length - 1) {
            const curr = path.charAt(idx);
            if (idx < path.length - 1) {
                const nxt = path.charAt(idx + 1);
                if ((curr === "/" && /^[a-zA-Z()]+$/.test(nxt)) || /^[a-zA-Z()]+$/.test(curr)) {
                    normalPath += curr;
                    idx++;
                }
                else { 
                    break;
                }
            }
            else {
                if (/^[a-zA-Z()]+$/.test(curr)) {
                    normalPath += curr;
                }
                idx++;
            }
        }
        return normalPath.toLowerCase();
    }

    createRouteKey(method, path) { 
        const routeKey = method.toUpperCase() + " " + this.normalizePath(path);
        return routeKey;
    }

    get(path, cb) {
		this.routes[this.createRouteKey("GET", path)] = cb;
    }

    use(cb) {
        this.middleware = cb;
    }

    listen(port, host) {
        this.server.listen(port, host);
    }

    handleConnection(sock) {
        sock.on("data", binaryData => { 
            this.handleRequest(sock, binaryData);
        });
    }

    handleRequest(sock, binaryData) { 
        const reqString = binaryData + "";
        const req = new Request(reqString);
        const res = new Response(sock);
        if (this.middleware !== null) {
            this.middleware(req,res, () => {
                this.processRoutes(req,res);
            });
        }
        else {  this.processRoutes(req,res);
        }
    }

    processRoutes(req,res){ 
        const method = req.method;
        const path = req.path;
        const routeKey = this.createRouteKey(method,path);
        
        if (Object.prototype.hasOwnProperty.call(this.routes, routeKey)) {
			this.routes[routeKey](req, res);
		}
		else{
            let res2;
            res2 = new Response(res.sock,404);
		}
	}
}


const serveStatic = function(basePath){
    return (req, res, next) => {
        const fn = path.join(basePath, req.path.replace(/\\/g, "/")).replace(/\\/g, "/");
        console.log(fn);
        fs.readFile(fn, (err, data) => {
            if (err) {
                next();
            }
            else {
                console.log("FOUND IT", err);
                res.set('Content-Type', this.getMIMEType(this.getExtension(fn)));
                res.send(data);
            }
        });
    };
};

module.exports = {
    HTTP_STATUS_CODES: HTTP_STATUS_CODES,
    MIME_TYPES: MIME_TYPES,
    getExtension: getExtension,
    getMIMEType: getMIMEType,
    Request,
    App,
    Response,
    static: serveStatic,
  };