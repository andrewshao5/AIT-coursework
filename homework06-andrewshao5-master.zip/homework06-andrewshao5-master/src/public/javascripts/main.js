document.addEventListener('DOMContentLoaded', main);
function showWinner(yourCards, dealerCards, gameDiv, buttonDiv){
  const dealerScore = calculateScore(dealerCards);
  const yourScore = calculateScore(yourCards);
  let result = document.createElement('p');
 
  if (yourScore > 21){
    result.appendChild(document.createTextNode("You Lose"));
  } else if (dealerScore > 21) {
    result.appendChild(document.createTextNode("You Win!"));
  } else if (dealerScore > yourScore) {
    result.appendChild(document.createTextNode("You Lose"));
  } else if (yourScore > dealerScore){
    result.appendChild(document.createTextNode("You Win"));
  } else {
    result.appendChild(document.createTextNode("Draw"));
  }
 
  gameDiv.replaceChild(document.createElement('div').appendChild(result), buttonDiv);
}
 
function gameOver(yourCards, dealerCards){
  const yourScore = calculateScore(yourCards);
  const dealerScore = calculateScore(dealerCards);
  if (yourScore >= 21 || dealerScore >= 21){
    return true;
  }
  return false;
}
 
function dealerTurn(hand, deck, div){
  if (calculateScore(hand) < 17){
    hand.push(deck.shift());
    const cardImage = document.createElement('img');
    cardImage.setAttribute('src', 'cards/card_back.png');
    div.appendChild(cardImage);
    return false
  }
  return true;
 
}
 
function displayCards(cards, div, hide){
 
  if (div.getAttribute('class') === "dealer" && hide === true){
    cards.forEach((card) => {
      const cardImage = document.createElement('img');
      if (cards.indexOf(card) === 0){
        cardImage.setAttribute('src', 'cards/' + card);
      } else {
        cardImage.setAttribute('src', 'cards/card_back.png');
      }
      div.appendChild(cardImage);
    });
  } else {
    cards.forEach((card) => {
      const cardImage = document.createElement('img');
      cardImage.setAttribute('src', 'cards/' + card);
      div.appendChild(cardImage);
    });
  }
}
 
function calculateScore(hand){
  let score = 0;
  let aces = 0;
  hand.forEach((card) => {
    const value = card.split("_")[0];
    if (value === "jack" || value === "queen" || value === "king"){
      score += 10;
    } else if (value === "ace"){
      aces++;
    } else {
      score += parseInt(value);
    }
  });
 
  if (aces === 1){
    if (score + 11 < 21){
      score += 11;
    } else {
      score ++;
    }
  } else if (aces >= 2){
    score += (aces - 1)
    if (score + 11 < 21){
      score += 11;
    } else {
      score++;
    }
  }
 
  return score;
}
 
function generateDeck(startValues){
  const suits = ["hearts", "diamonds", "spades", "clubs"];
  const cards = [];
  const topCards = [];
 
  for (let i = 0; i < startValues.length; i++){
    const suit = suits[Math.floor(Math.random() * 4)];
    if (startValues[i] === "A"){
      if (topCards.indexOf("ace_of_" + suit + ".png") > -1){
        i--;
      } else {
        topCards.push("ace_of_" + suit + ".png");
      }
    } else if (startValues[i] === "J"){
      if (topCards.indexOf("jack_of_" + suit + "2.png") > -1){
        i--;
      } else {
        topCards.push("jack_of_" + suit + "2.png");
      }
    } else if (startValues[i] === "Q"){
      if (topCards.indexOf("queen_of_" + suit + "2.png") > -1){
        i--;
      } else {
        topCards.push("queen_of_" + suit + "2.png");
      }
    } else if (startValues[i] === "K"){
      if (topCards.indexOf("king_of_" + suit + "2.png") > -1){
        i--;
      } else {
        topCards.push("king_of_" + suit + "2.png");
      }
    } else {
      if (topCards.indexOf(startValues[i] + "_of_" + suit + ".png") > -1){
        i--;
      } else {
        topCards.push(startValues[i] + "_of_" + suit + ".png");
      }
    }
  }
 
  for (let i = 1; i <= 52; i++){
    let card = "";
    if (i % 13 === 1){
      card = "ace_of_" + suits[Math.floor((i - 1) / 13)] + ".png";
    } else if (i % 13 === 11){
      card = "jack_of_" + suits[Math.floor((i - 1) / 13)] + "2.png";
    } else if (i % 13 === 12){
      card = "queen_of_" + suits[Math.floor((i - 1) / 13)] + "2.png";
    } else if (i % 13 === 0){
      card = "king_of_" + suits[Math.floor((i - 1) / 13)] + "2.png";
    } else {
      card = i % 13 + "_of_" + suits[Math.floor((i - 1) / 13)] + ".png";
    }
 
    if (topCards.indexOf(card) === - 1){
      cards.push(card);
    }
  }
  shuffle(cards);
 
  return topCards.concat(cards);
}
 
function shuffle(array) {
    for (let i = array.length - 1; i > 0; i--) {
        const j = Math.floor(Math.random() * (i + 1));
        [array[i], array[j]] = [array[j], array[i]];
    }
}
 
function main(){
  const startValues = []
  const button = document.querySelector(".playBtn");
  button.addEventListener('click', function (event){
    event.preventDefault();
    const form = document.querySelector('div.start');
    if (form.style.display === "none"){
      form.style.display = "block";
    } else {
      form.style.display = "none";
    }
    document.getElementById('startValues').value.split(',').forEach((value) => {
      startValues.push(value);
    });
 
    let cards = generateDeck(startValues);
    const yourCards = [];
    const dealerCards = [];
 
    dealerCards.push(cards.shift());
    yourCards.push(cards.shift());
    dealerCards.push(cards.shift());
    yourCards.push(cards.shift());
 
    const gameElement = document.querySelector('.game')
 
    const dealerScore = document.createElement('p');
    dealerScore.appendChild(document.createTextNode("Dealer Score - ?"));
 
    const dealerBox = document.createElement('div');
    dealerBox.setAttribute('class', 'dealer');
    dealerBox.appendChild(dealerScore);
    gameElement.appendChild(dealerBox);
 
    const userDiv = document.createElement('div');
    userDiv.setAttribute('class', 'user');
    gameElement.appendChild(userDiv);
    const yourScore = document.createElement('p');
    userDiv.appendChild(yourScore);
    yourScore.appendChild(document.createTextNode("User Score - " + calculateScore(yourCards)));
 
    const buttonDiv = document.createElement('div');
    buttonDiv.setAttribute('class', 'buttons');
 
    const stand = document.createElement('button');
    stand.setAttribute('type', 'button');
    stand.appendChild(document.createTextNode("Stand"));
 
    const hit = document.createElement('button');
    hit.setAttribute('type', 'button');
    hit.appendChild(document.createTextNode("Hit"));
 
    buttonDiv.appendChild(hit);
    buttonDiv.appendChild(stand);
    gameElement.appendChild(buttonDiv);
    displayCards(dealerCards, dealerBox, true);
    displayCards(yourCards, userDiv);
 
    let dealerStand = false;
 
 
    hit.addEventListener('click', function(event){
      const card = cards.shift();
      yourCards.push(card);
      const cardImage = document.createElement('img');
      cardImage.setAttribute('src', 'cards/' + card);
      userDiv.appendChild(cardImage);
 
      yourScore.replaceChild(document.createTextNode("User Score - " + calculateScore(yourCards)), yourScore.firstChild);
      if (gameOver(yourCards, dealerCards)){
        for (let i = 1; i < dealerBox.childNodes.length; i++){
          dealerBox.childNodes[i].setAttribute('src', 'cards/' + dealerCards[i-1]);
        }
        dealerScore.replaceChild(document.createTextNode("Dealer Score - " + calculateScore(dealerCards)), dealerScore.firstChild);
 
        showWinner(yourCards, dealerCards, gameElement, buttonDiv);
 
      } else {
        dealerStand = dealerTurn(dealerCards, cards, dealerBox);
        if (gameOver(yourCards, dealerCards)){
          for (let i = 1; i < dealerBox.childNodes.length; i++){
            dealerBox.childNodes[i].setAttribute('src', 'cards/' + dealerCards[i-1]);
          }
          dealerScore.replaceChild(document.createTextNode("Dealer Score - " + calculateScore(dealerCards)), dealerScore.firstChild);
 
          showWinner(yourCards, dealerCards, gameElement, buttonDiv);
        }
      }
    });
 
    stand.addEventListener('click', function(event){
      if (dealerStand){
        showWinner(yourCards, dealerCards, gameDiv, buttonDiv);
      } else {
        while(!dealerTurn(dealerCards, cards, dealerBox)){}
 
        for (let i = 1; i < dealerBox.childNodes.length; i++){
          dealerBox.childNodes[i].setAttribute('src', 'cards/' + dealerCards[i-1]);
        }
        dealerScore.replaceChild(document.createTextNode("Dealer Score - " + calculateScore(dealerCards)), dealerScore.firstChild);
        showWinner(yourCards, dealerCards, gameElement, buttonDiv);
 
      }
    });
  });
}
 
 
 
 
 
