/*
// kaomoji
class Kaomoji{
constructor(value,emotions=[]) {
  this.value = value;
  const emotionsLower = emotions.map(element => {
  return element.toLowerCase();
});
  this.emotions = emotionsLower;
}
isEmotion(temp){
const lowerTemp = temp.toLowerCase();
if(this.emotions.includes(lowerTemp)){
return true;
}
else{
  
return false;

}}
}
//module.exports = {Kaomoji};

*/
