// app.js
const express = require('express');
const app = express();
const kaomojis = [];

app.set('view engine', 'hbs');
app.use(express.static('public'));
app.use(express.urlencoded({extended: false}));

app.use(function(req, res, next) {
	console.log(req.method, req.path, req.query);
	next();
});

 
app.get('/', function(req, res){
  res.redirect('/editor');
});
app.get('/editor', (req, res)=>{
  res.render('editor', {layout : 'layout'});
});

app.get('/dictionary', (req, res) => {
//const search = req.query.emotion;
res.render('dictionary', {kaomojis});
});

app.post('/dictionary', ( req, res ) => {
console.log(req.body.emotion);
kaomojis.push({emotions: req.body.emotion, value: req.body.value}); 

/*
For some reason this is pushing it outside of a 2d array and I unfortunately I do not know how to fix it
[
 { emotions: [Array], value: '.·´¯`(>▂<)´¯`·.' },
    { emotions: [Array], value: '（・□・；）' },
    { emotions: [Array], value: '(•᷉ुε ू•᷈,)' }
  ],
  { emotions: 'test', value: 'test' }
]
*/

console.log(kaomojis); 
res.redirect('/dictionary');
});

const fs = require('fs');
fs.readFile('./code-samples/kaomojiData.json', (err, data) => {                                                                                      
  if(err) {                                                                                                                    
    console.log('error', err);                                                                                                 
  } else {                    
    kaomojis.push(JSON.parse(data)); 
console.log(kaomojis);                                
    app.listen(3000);                                                                                                          
  }                                                                                                                            
});  

   
