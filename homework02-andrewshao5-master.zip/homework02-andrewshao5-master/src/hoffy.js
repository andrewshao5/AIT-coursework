// hoffy.js
function getEvenParam(s1, s2, s3, ...sN) {
    if (s1 == undefined) {
    return [];
    }
    else{
    sN.unshift(s3);
    sN.unshift(s2);
    sN.unshift(s1);
	return sN.filter((element, index) => {
  return index % 2 === 0;})}
}
result = getEvenParam();
console.log(result);
