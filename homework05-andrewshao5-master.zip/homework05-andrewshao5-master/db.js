const mongoose = require('mongoose');
const Schema = mongoose.Schema;
const mongooseOpts = {
  useNewUrlParser: true,  
  useUnifiedTopology: true
};

const Review = new Schema({

    courseNumber : String,
    courseName : String,
    semester : String,
    year : Number,
    professor : String,
    review : String

});

mongoose.model('Review', Review);
mongoose.connect('mongodb://localhost/hw05', mongooseOpts, (err) => {
  if (err) {
    console.log(err);
  } else {
    console.log('connected to database'); 
  }
});
