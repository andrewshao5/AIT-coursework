const express = require('express');
const router = express.Router();

router.get('/add', (req, res) => {

});

router.post('/add', (req, res) => {

});

router.get('/mine', (req, res) => {

});

module.exports = router;
