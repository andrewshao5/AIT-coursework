//as11897
const express = require('express');
const app = express();
const path = require("path");
const session = require('express-session');
const publicPath = path.resolve(__dirname, "public");
app.use(express.static(publicPath));
app.set('view engine', 'hbs');
require('./db.js');
const mongoose = require('mongoose');
const Review = mongoose.model('Review');
app.use(express.urlencoded({
    extended: false
}));

const sessionOptions = {
    secret: 'secret for signing session id',
    saveUninitialized: false,
    resave: false
};
app.use(session(sessionOptions));

function sessionCounter(req, res, next) {
    res.locals.count = req.session.count;
    next();
}


app.use(sessionCounter);



app.get('/', function(req, res) {

    if (res.locals.count === undefined) {
        res.locals.count = 1;
        req.session.count = 1;
    }
    req.session.count += 1;
    const query = {};
    if (req.query.semester !== "") {
        query.semester = req.query.semester;
    }
    if (req.query.year !== "") {
        query.year = req.query.year;
    }
    if (req.query.professor !== "") {
        query.professor = req.query.professor;
    }

    if (req.query.semester || req.query.year || req.query.professor) {
        Review.find(query, function(err, reviews, count) {
            res.render('index', {
                reviews: reviews,
                sesh: req.session.views
            });
        });
    } else {
        Review.find(function(err, reviews, count) {
            res.render('index', {
                reviews: reviews
            });
        });
    }
});


app.get('/reviews/add', function(req, res) {

    req.session.count += 1;
    res.render('add');

});


app.post('/reviews/add', function(req, res) {

    new Review({
        courseNumber: req.body.courseNumber,
        courseName: req.body.courseName,
        semester: req.body.semester,
        year: req.body.year,
        professor: req.body.professor,
        review: req.body.review,
        sessionID: req.session.id,
    }).save(function(err, review) {
        res.redirect('/');
    });

});



app.get('/reviews/mine', function(req, res) {

    req.session.count += 1;
    Review.find({
        sessionID: req.session.id
    }, function(err, reviews) {

        if (err) {
            console.log(err);
        }

        res.render('mine', {
            reviews: reviews
        });

    });
});
app.listen(process.env.PORT || 3000);