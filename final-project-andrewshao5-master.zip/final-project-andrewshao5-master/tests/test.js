const puppeteer = require("puppeteer");
var expect = require('expect');


describe("if already logged in, expect going to /login to redirect to index",()=>{
    it("test1",async()=>{
    const browser = await puppeteer.launch({
      headless:false,
slowMo: 100
    })
    const page = await browser.newPage()
    await page.goto("http://localhost:3000/login");
    await page.type('#username', 'username');
    await page.type('#password', 'password');
    await page.click('#submit');
await page.goto("http://localhost:3000/login");
    expect( page.url() ).toBe("http://localhost:3000/")
    await page.close();
  });
    });


describe("if trying to navigate to /manage without being logged in, expect redirect to login",()=>{
     it("test2",async()=>{
    const browser = await puppeteer.launch({
      headless:false,
slowMo: 100
    })
    const page = await browser.newPage()
    await page.goto("http://localhost:3000/manage");
    expect( page.url() ).toBe("http://localhost:3000/login")
    await page.close();
  });
    });

describe("expect successful login to redirect to manage",()=>{
     it("test3",async()=>{
    const browser = await puppeteer.launch({
      headless:false,
slowMo: 100
    })
    const page = await browser.newPage()
    await page.goto("http://localhost:3000/login");
    await page.type('#username', 'username');
    await page.type('#password', 'password');
    await page.click('#submit');
    expect( page.url() ).toBe("http://localhost:3000/manage")
    await page.close();
  });
    });

describe("expect unsuccessful login to display error and not redirect",()=>{
     it("test4",async()=>{
    const browser = await puppeteer.launch({
      headless:false,
slowMo: 100
    })
    const page = await browser.newPage()
    await page.goto("http://localhost:3000/login");
    await page.type('#username', 'incorrect');
    await page.type('#password', 'incorrect');
    await page.click('#submit');
   try {
  await page.$(".error")
  console.log("error appears")
} catch {
  console.log("error does not appear")
}
    await page.close();
  });
    });