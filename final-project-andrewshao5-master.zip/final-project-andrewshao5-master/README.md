The content below is an example project proposal / requirements document. Replace the text below the lines marked "__TODO__" with details specific to your project. Remove the "TODO" lines.


# Online forum

## Overview

(__TODO__: a brief one or two paragraph, high-level description of your project_)

There are already a lot of online internet forums, but I wanted to try my hand at creating one as well. There will be anonymous users and admin. Anonymous users can leave and view messages, while admin users can choose what messages will be shown.
## Data Model

Example web stat data
{
visitcount: //number of visitors
messages: //number of messages
}

message
{
username: //username
spoiler: //message hidden or not
text: //message body
timestamp: //time posted
}

user
{
username: //username
hash: //password hash
}


## [Link to Commented First Draft Schema](/db.js) 

## Wireframes

![Alt text](/public/img/home.png?raw=true "display")
<br/>
/ - homepage

![Alt text](/public/img/message.png?raw=true "display")
<br/>
/add - message board

![Alt text](/public/img/login.png?raw=true "display")
<br/>
/manage  -page to login

## Site map(/public/img/sitemap.png?raw=true "display")

(__TODO__: draw out a site map that shows how pages are related to each other_)

Here's a [complex example from wikipedia](https://upload.wikimedia.org/wikipedia/commons/2/20/Sitemap_google.jpg), but you can create one without the screenshots, drop shadows, etc. ... just names of pages and where they flow to.

## User Stories or Use Cases

(__TODO__: write out how your application will be used through [user stories](http://en.wikipedia.org/wiki/User_story#Format) and / or [use cases](https://www.mongodb.com/download-center?jmp=docs&_ga=1.47552679.1838903181.1489282706#previous)_)

1. As a regular user, I can leave and view messages.
2. As a admin I can do all the things a regular user can and also approve messages and allow them to be viewed or decline messages and delete them.
3. Messages can be seen by anyone
4. Users can create accounts with usernames and passwords.

## Research Topics

(3 points) Perform client side form validation using custom JavaScript or JavaScript library

(2 points) Use a CSS framework throughout your site, use a reasonable of customization of the framework (don't just use stock Bootstrap - minimally configure a theme)

(3 points) Unit testing with JavaScript

## [Link to Initial Main Project File](/app.js) 

(__TODO__: create a skeleton Express application with a package.json, app.js, views folder, etc. ... and link to your initial app.js_)

## Annotations / References Used

(__TODO__: list any tutorials/references/etc. that you've based your code off of_)

1. https://alexanderpaterson.com/posts/how-to-start-unit-testing-your-express-apps

2. https://ankit-m.medium.com/ui-testing-with-puppeteer-and-mocha-part-1-getting-started-b141b2f9e21
