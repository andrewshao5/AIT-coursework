const mongoose = require('mongoose'),
	URLSlugs = require('mongoose-url-slugs'),
  passportLocalMongoose = require('passport-local-mongoose');


const User = new mongoose.Schema({
  username:String,
  hash: String
});

User.plugin(passportLocalMongoose);

mongoose.model('User',User);

const Message = new mongoose.Schema({
	name: String,
  display:Boolean,
  spoiler: Boolean,
  text: String,
session_id: String
});

Message.plugin(URLSlugs('name'));

mongoose.model('Message',Message);

const siteData = new mongoose.Schema({
  website_id: Number,
  visited: Number,
  messages: Number,
newmessages:Number
});

mongoose.model('Data',siteData);

// is the environment variable, NODE_ENV, set to PRODUCTION? 
let dbconf;
if (process.env.NODE_ENV === 'PRODUCTION') {
 // if we're in PRODUCTION mode, then read the configration from a file
 // use blocking file io to do this...
 const fs = require('fs');
 const path = require('path');
 const fn = path.join(__dirname, 'config.json');
 const data = fs.readFileSync(fn);

 // our configuration file will be in json, so parse it and set the
 // conenction string appropriately!
 const conf = JSON.parse(data);
 dbconf = conf.dbconf;
} else {
 // if we're not in PRODUCTION mode, then use
 dbconf = 'mongodb://localhost/projectdb';
}
mongoose.connect(dbconf);
