const DEFAULT_AIT_PORT = 3000;
 
// database setup
require('./db');
const mongoose = require('mongoose');
 
// express
const express = require('express');
const app = express();
app.use(express.json());
// static files
const path = require("path");
const publicPath = path.resolve(__dirname, "public");
app.use(express.static(publicPath));
 
// body parser
app.use(express.urlencoded({ extended: false }));
app.set('view engine', 'hbs');
 
const Review = mongoose.model('Review');
 
app.get('/api/reviews', async function(req, res) {
  let query = {};
 
  if (req.query.year !== undefined && req.query.year !== ""){
    query["year"] = req.query.year;
  }
 
  if (req.query.semester !== "" && req.query.semester !== undefined){
    query["semester"] = req.query.semester;
  }
 
   Review.find(query, function (err, reviews) {

        if (err) {
            console.log("error");
        }
        else {
            res.json(reviews);
        }
  });
});
 
app.post('/api/review/create', (req, res) => {
     const review = new Review({

        name: req.body.name,
        semester: req.body.semester,
        year: req.body.year,
        review: req.body.review,
    });

    review.save(function(err, review){

        if(err){
            res.json({error: err.message});
        }
        else{
            res.json(review);
        }
    });
});
 
app.listen(process.env.PORT || DEFAULT_AIT_PORT, (err) => {
  console.log('Server started (ctrl + c to shut down)');
});
 
 
 
                                                                  